<!doctype html>
<html lang="en-US">
		<?php include("head.php");?>
	<body>
		<!--preloader-->
       <?php include("loader.php");?>
        <!--end preloader-->
		<div class="site">
			<?php include("header.php");?>
			<!-- <div class="noo-page-heading">
				<div class="container">
					<div class="noo-page-breadcrumb">
						<div class="breadcrumb-wrap">
 							<span><a href="#" class="home">Home</a></span><i>&#047;</i> <span><span>Members</span></span>
 						</div>
					</div>
				</div> 
			</div> -->
			<div class="container-wrap">
				<div class="default-p container">
					<div class="row">
						<div class="noo-main col-md-12">
 							<div class="row row-fluid">
 								<div class="nocontainer">
									<div class="col-sm-12">
										<div class="noo_team">
											<h2 class="noo-team-title">FCR4 Crew Admins </h2>
											<p class="noo-team-ds">
												
											</p>
												<div class="row noo-team-contents">
												<div class="col-md-4 col-sm-6">
													<div class="noo_team_item">
														<div class="team_thumbnail">
															<img width="770" height="770" src="images/admin/dennisdecastro.jpg" align="middle"/>
															<div class="team-info">
																<h4 class="team_name">#0001</h4>
																<span class="team_position">FCr4 Founder</span>
															</div>
														</div>
														<div class="team-detail">
															<div class="team-detail-position">
																<p class="ds">
																	Dennis De Castro 
																</p>
																<p class="ds">
																	FCr4 Founder
																</p>
																<p class="ds">
																	Civic 1.8 E Lunar Silver Metallic
																</p>
																
															</div>
														</div>
													</div>
												</div>
												<div class="col-md-4 col-sm-6">
													<div class="noo_team_item">
														<div class="team_thumbnail">
															<img width="770" height="770" src="images/admin/kaseychiu.jpg" align="middle"/>
															<div class="team-info">
																<h4 class="team_name">#0002</h4>
																<span class="team_position">FCr4 Multimedia Artist</span>
															</div>
														</div>
														<div class="team-detail">
															<div class="team-detail-position">
																<p class="ds">
																	Kasey Chiu 
																</p>
																<p class="ds">
																	FCr4 Multimedia Artist
																</p>
																<p class="ds">
																	Civic 1.8 E Modern Steel Metallic
																</p>
																<!-- <div class="team_socials">
																	<span class="team_social">
																		<span class="social-name">Follow on facebook</span>
																		<a href="#" class="fa fa-facebook"></a>
																	</span>
																	<span class="team_social">
																		<span class="social-name">Follow on twitter</span>
																		<a href="#" class="fa fa-twitter"></a>
																	</span>
																	<span class="team_social">
																		<span class="social-name">Follow on google</span>
																		<a href="#" class="fa fa-google-plus"></a>
																	</span>
																</div> -->
															</div>
														</div>
													</div>
												</div>

												<div class="col-md-4 col-sm-6">
													<div class="noo_team_item">
														<div class="team_thumbnail">
															<img width="770" height="770" src="images/admin/eurwyntagum.jpg" align="middle"/>
															<div class="team-info">
																<h4 class="team_name">#0003</h4>
																<span class="team_position">FCr4 Chief Justice</span>
															</div>
														</div>
														<div class="team-detail">
															<div class="team-detail-position">
																<p class="ds">
																	Norman Tagum
																</p>
																<p class="ds">
																	FCr4 Chief Justice
																</p>
																<p class="ds">
																	Civic 1.8 E 
																</p>
																
															</div>
														</div>
													</div>
												</div>

												<div class="col-md-4 col-sm-6">
													<div class="noo_team_item">
														<div class="team_thumbnail">
															<img width="770" height="770" src="images/admin/einjheltlstas.jpg" align="middle" />
															<div class="team-info">
																<h4 class="team_name">#0007</h4>
																<span class="team_position">FCr4 Finance Head</span>
															</div>
														</div>
														<div class="team-detail">
															<div class="team-detail-position">
																<p class="ds">
																	Angelica Talastas
																</p>
																<p class="ds">
																	FCr4 Finance Head
																</p>
																<p class="ds">
																	Civic 1.8 E 
																</p>
																
															</div>
														</div>
													</div>
												</div>

												<div class="col-md-4 col-sm-6">
													<div class="noo_team_item">
														<div class="team_thumbnail">
															<img width="770" height="770" src="images/admin/nickdrag.jpg" align="middle"/>
															<div class="team-info">
																<h4 class="team_name">#0008</h4>
																<span class="team_position">Head Laguna Chapter</span>
															</div>
														</div>
														<div class="team-detail">
															<div class="team-detail-position">
																<p class="ds">
																	Nick Drag 
																</p>
																<p class="ds">
																	Head Laguna Chapter
																</p>
																<p class="ds">
																	Civic 1.8 E 
																</p>
																
															</div>
														</div>
													</div>
												</div>
												<div class="col-md-4 col-sm-6">
													<div class="noo_team_item">
														<div class="team_thumbnail">
															<img width="770" height="770" src="images/admin/lloydwindell.jpg" align="middle"/>
															<div class="team-info">
																<h4 class="team_name">#0009</h4>
																<span class="team_position">Head Batangas Chapter</span>
															</div>
														</div>
														<div class="team-detail">
															<div class="team-detail-position">
																<p class="ds">
																	Lloyd Windell Aguilar 
																</p>
																<p class="ds">
																	Head Batangas Chapter
																</p>
																<p class="ds">
																	Civic 1.8 E 
																</p>
																
															</div>
														</div>
													</div>
												</div>





												<div class="col-md-4 col-sm-6">
													<div class="noo_team_item">
														<div class="team_thumbnail">
															<img width="770" height="770" src="images/admin/reincatabay.jpg" align="middle"/>
															<div class="team-info">
																<h4 class="team_name">#0020</h4>
																<span class="team_position">Head Southern Manila</span>
															</div>
														</div>
														<div class="team-detail">
															<div class="team-detail-position">
																<p class="ds">
																	Rein Catabay
																</p>
																<p class="ds">
																	Head Southern Manila
																</p>
																<p class="ds">
																	Civic 1.8 E Lunar Silver Metallic
																</p>
																
															</div>
														</div>
													</div>
												</div>
												<div class="col-md-4 col-sm-6">
													<div class="noo_team_item">
														<div class="team_thumbnail">
															<img width="770" height="770" src="images/admin/bhokespiritu.jpg" align="middle""/>
															<div class="team-info">
																<h4 class="team_name">#0021</h4>
																<span class="team_position">Head Cavite Chapter</span>
															</div>
														</div>
														<div class="team-detail">
															<div class="team-detail-position">
																<p class="ds">
																	Bhok Espiritu
																</p>
																<p class="ds">
																	Head Cavite Chapter
																</p>
																<p class="ds">
																	Civic 1.8 E 
																</p>
																
															</div>
														</div>
													</div>
												</div>
												
												<div class="col-md-4 col-sm-6">
													<div class="noo_team_item">
														<div class="team_thumbnail">
															<img width="770" height="770" src="images/admin/marclopez.jpg" align="middle"/>
															<div class="team-info">
																<h4 class="team_name">#0022</h4>
																<span class="team_position">Head Rizal Chapter</span>
															</div>
														</div>
														<div class="team-detail">
															<div class="team-detail-position">
																<p class="ds">
																	Marc Christopher Lopez
																</p>
																<p class="ds">
																	Head Rizal Chapter

																</p>
																<p class="ds">
																	Civic RS Turbo Rallye Red
																</p>
																
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>  
					</div> 
				</div> 
			</div>
			<?php include("footer.php");?> 
		</div> 

		<script type='text/javascript' src='http://code.jquery.com/jquery-1.11.3.min.js'></script>
		<script type='text/javascript' src='js/jquery-migrate.min.js'></script>
		<script type='text/javascript' src='js/jquery.themepunch.tools.min.js'></script>
		<script type='text/javascript' src='js/jquery.themepunch.revolution.min.js'></script>
		<script type='text/javascript' src='js/modernizr-2.7.1.min.js'></script>
		<script type='text/javascript' src='js/imagesloaded.pkgd.min.js'></script>
		<script type='text/javascript' src='js/jquery.carouFredSel-6.2.1.js'></script>
		<script type='text/javascript' src='js/jquery.touchSwipe.min.js'></script>
		<script type='text/javascript' src='js/bootstrap.min.js'></script>
		<script type='text/javascript' src='js/hoverIntent-r7.min.js'></script>
		<script type='text/javascript' src='js/superfish-1.7.4.min.js'></script>
		<script type='text/javascript' src='js/main.js'></script>
		<script type='text/javascript' src='js/mediaelement-and-player.js'></script>
		<script type='text/javascript' src='js/player.js'></script>
	</body>
</html>