
<footer class="colophon site-info">
				<div class="colophon wigetized">
					<div class="background-footer"></div>
					<div class="container">
						<div class="row noo-footer-main">
							<div class="col-md-6 col-sm-6">
								<div class="widget widget_text">
									<h4 class="widget-title">About Us</h4>
									<div class="textwidget">
										<p>
											This group is not related to any car groups / clubs / organizations. We will not gather points to be an official member, but we are required to attend QUARTERLY GT's. Everyone who owns a CIVIC FC is a member and valid as an OFFICIAL member as long as you pass the REQUIREMENTS. We are NOT here to do BUSINESS. We just want to know more about our CAR. Thanks!.
										</p>
										<p>
											Note:
												We accept members from Region 4 and Southern Manila Only! 
												Click Register and email us a photo of your FC at admin@fcr4crew.com
										</p>
									</div>
								</div>
							</div>
							
							<div class="col-md-6 col-sm-6">
								<div class="widget tribe-events-adv-list-widget">
									<h4 class="widget-title">Upcoming Events</h4>
									<div class="tribe-mini-calendar-event">
										<div class="list-date">
											<span class="list-dayname">Sun</span>
											<span class="list-daynumber">30</span>
										</div>
										<div class="list-info">
											<h2 class="entry-title summary">
												<a href="#">April GT</a>
											</h2>
											<div class="duration">
												<span class="date-start dtstart">April 30-8:00 am</span>
												-
												<span class="date-end dtend"> pm</span>
											</div>
										</div>  
									</div>
									<!-- <div class="tribe-mini-calendar-event">
										<div class="list-date">
											<span class="list-dayname">Mon</span>
											<span class="list-daynumber">28</span>
										</div>
										<div class="list-info">
											<h2 class="entry-title summary">
												<a href="#">Editions in the gallery cafe</a>
											</h2>
											<div class="duration">
												<span class="date-start dtstart">June 1-9:30 pm</span>
												-
												<span class="date-end dtend">October 31-10:30 pm</span>
											</div>
										</div>  
									</div> -->
									<!-- <div class="tribe-mini-calendar-event">
										<div class="list-date">
											<span class="list-dayname">Mon</span>
											<span class="list-daynumber">28</span>
										</div>
										<div class="list-info">
											<h2 class="entry-title summary">
												<a href="#">Ultra Music Festival</a>
											</h2>
											<div class="duration">
												<span class="date-start dtstart">June 3-8:00 am</span>
												-
												<span class="date-end dtend">November 30-5:00 pm</span>
											</div>
										</div>  
									</div> -->
								</div>
							</div>
							
						</div>  
						<div class="noo-footer-bottom">
							<div class="widget widget_noo_infomation">
								<ul class="noo-infomation">
									<li>
										<span class="fa fa-map-marker infomation-left"></span>
										<address>Region 4 and Southern Manila Philippines</address>
									</li>
									<li class="info-phone">
										<a href="https://www.facebook.com/groups/fcr4crew/"><span class="fa fa-facebook infomation-left"></span></a>
										<!-- <span>N/A</span> -->
									</li>
									<li >
										<span class="fa fa-envelope-o infomation-left"></span>
										<span>admin@fcr4crew.com</span>
									</li>
								</ul>
							</div>
							<div class="widget widget_noo_social">
								<div class="noo_social">
									<div class="social-all">
										<span class="footer-social">
										
											<span>
												<a href="https://www.facebook.com/FCR4Crew/" class="fa fa-facebook"></a>
												<div class="fb-like" data-href="https://www.facebook.com/FCR4Crew/" data-layout="button_count" data-action="like" data-size="large" data-show-faces="false" data-share="true"></div>
											</span>	
										</span>


										<span class="footer-social">
										</span>
										<span class="footer-social">
										</span>
										<span class="footer-social">
										</span>

										<span class="footer-social">
											<span>
												<a href="www.instagram.com/fcr4crew/?hl=en" class="fa fa-instagram"></a>
												<span><strong class="instagram"></strong> Followers on instagram</span>	
											</span>		
										</span>

									</div>
								</div>
							</div>
					</div>  
				</div>  
			</footer>  
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.js"></script>			
<script type="text/javascript">

  var token = '4290943462.1677ed0.843179ff2e174626ad478f6e2e6d4fbd';

  $.ajax({
      url: 'https://api.instagram.com/v1/users/self',
      dataType: 'jsonp',
      type: 'GET',
      data: {access_token: token},
      success: function(data){
          var follows = data['data']['counts']['followed_by'];
          $(".instagram").text(follows);
      },
      error: function(data){
          console.log(data);
      }
  });

 </script>

<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.8&appId=284361728663182";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>