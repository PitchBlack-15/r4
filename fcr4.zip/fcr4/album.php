<!doctype html>
<html lang="en-US">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0"/>
 		<link rel="shortcut icon" href="images/favicon.png"/>
		<title>Albums | WeMusic - Music Band Event</title>

		<link rel='stylesheet' href='css/settings.css' type='text/css' media='all'/>
		<link rel='stylesheet' href='css/widget-calendar-full.css' type='text/css' media='all'/>
		<link rel='stylesheet' href='css/style.css' type='text/css' media='all'/>
		<link rel='stylesheet' href='css/commerce.css' type='text/css' media='all'/>
		<link rel='stylesheet' href='css/font-awesome.min.css' type='text/css' media='all'/>
		<link rel='stylesheet' href='css/jquery.mb.YTPlayer.css' type='text/css' media='all'/>
		<link rel='stylesheet' href='css/owl.carousel.css' type='text/css' media='all'/>
		<link rel='stylesheet' href='css/owl.theme.css' type='text/css' media='all'/>
		<link rel='stylesheet' href='css/nivo-lightbox.css' type='text/css' media='all'/>
		<link rel='stylesheet' href='css/nivo-default.css' type='text/css' media='all'/>
		<link rel='stylesheet' href='css/mediaelementplayer.css' type='text/css' media='all'/>
		<link rel='stylesheet' href='css/layout.css' type='text/css' media='all'/>

		<link rel='stylesheet' href='http://fonts.googleapis.com/css?family=Dosis:100,300,400,700,900,300italic,400italic,700italic,900italic' type='text/css' media='all'/>

		<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
            <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
	</head>
	<body>
		<!--preloader-->
        <div id="loading">
			<div id="loading-center">
				<div id="loading-center-absolute">
					<div class="object"></div>
					<div class="object"></div>
					<div class="object"></div>
					<div class="object"></div>
					<div class="object"></div>
					<div class="object"></div>
					<div class="object"></div>
					<div class="object"></div>
					<div class="object"></div>
					<div class="object"></div>
				</div>
			</div> 
		</div>
        <!--end preloader-->
		<div class="site">
			<?php include("header.php");?>
			<div class="noo-page-heading">
				<div class="container">
					<div class="noo-page-breadcrumb">
						<div class="breadcrumb-wrap">
 							<span><a href="#" class="home">Home</a></span><i>&#047;</i> <span><span>Album</span></span>
 						</div>
					</div>
				</div> 
			</div>
			<div class="container-wrap">
				<div class="main-content container">
					<div class="row">
						<div class="noo-main noo-archive-album">
							<div class="noo_albums-wrap clearfix">
								<ul class="noo_albums">
									<li class="col-md-4 col-sm-6">
										<div class="noo_album-container">
											<figure>
												<div class="noo_album-wrap">
													<div class="noo_album-images">
														<a href="#">
															<img width="500" height="700" src="images/album/album-thumb-370x482.jpg" alt="rock17"/>
														</a>
													</div>
												</div>
												<figcaption>
													<div class="noo_album-info">
														<h3 class="noo_album_title">
															<a href="#">Happy music day</a>
														</h3>
														<div class="noo_album-category">
															<a href="#">Pop</a><a href="#">Rock</a>
														</div>
													</div>
													<div class="noo_album-loop-actions">
														<a href="#"><i class="fa fa-link"></i> Detail</a>
														<a href="#" data-songs='[
															{
																&quot;id&quot;:&quot;album_1&quot;,

																&quot;artist&quot;:&quot;&lt;a href=\&quot;javascript:void(0)\&quot;&gt;Maroon 5 ft Wiz Khalifa&lt;\/a&gt;&quot;,
					
																&quot;file&quot;:&quot;http:\/\/wp.nootheme.com\/wemusic\/wp-content\/uploads\/2015\/06\/Payphone-Maroon-5-ft-Wiz-Khalifa.mp3&quot;,

																&quot;thumb&quot;:&quot;&lt;img width=\&quot;150\&quot; height=\&quot;150\&quot; src=\&quot;images\/album\/album-thumb-40x40.jpg\&quot; alt=\&quot;rock17\&quot; \/&gt;&quot;,

																&quot;name&quot;:&quot;Payphone&quot;,

																&quot;url&quot;:&quot;#&quot;,

																&quot;album&quot;:&quot;Happy music day&quot;
															},
															{
																&quot;id&quot;:&quot;album_2&quot;,

																&quot;artist&quot;:&quot;&lt;a href=\&quot;javascript:void(0)\&quot;&gt;Engelbert Humperdinck&lt;\/a&gt;&quot;,

																&quot;file&quot;:&quot;http:\/\/wp.nootheme.com\/wemusic\/wp-content\/uploads\/2015\/06\/Quando-Quando-Engelbert-Humperdinck-Engelbert-Humperdinck.mp3&quot;,

																&quot;thumb&quot;:&quot;&lt;img width=\&quot;150\&quot; height=\&quot;150\&quot; src=\&quot;images\/album\/album-thumb-40x40.jpg\&quot; alt=\&quot;rock17\&quot; \/&gt;&quot;,

																&quot;name&quot;:&quot;Quando Quando&quot;,

																&quot;url&quot;:&quot;#&quot;,

																&quot;album&quot;:&quot;Happy music day&quot;
															},
															{
																&quot;id&quot;:&quot;album_3&quot;,

																&quot;artist&quot;:&quot;&lt;a href=\&quot;javascript:void(0)\&quot;&gt;Modern Talking&lt;\/a&gt;&quot;,

																&quot;file&quot;:&quot;http:\/\/wp.nootheme.com\/wemusic\/wp-content\/uploads\/2015\/06\/No-Face-No-Name-No-Number-Modern-Talking.mp3&quot;,

																&quot;thumb&quot;:&quot;&lt;img width=\&quot;150\&quot; height=\&quot;150\&quot; src=\&quot;images\/album\/album-thumb-40x40.jpg\&quot; alt=\&quot;rock17\&quot; \/&gt;&quot;,

																&quot;name&quot;:&quot;No Face No Name No Number&quot;,

																&quot;url&quot;:&quot;#&quot;,

																&quot;album&quot;:&quot;Happy music day&quot;
															},
															{
																&quot;id&quot;:&quot;album_4&quot;,

																&quot;artist&quot;:&quot;&lt;a href=\&quot;javascript:void(0)\&quot;&gt;The Wanted&lt;\/a&gt;&quot;,

																&quot;file&quot;:&quot;http:\/\/wp.nootheme.com\/wemusic\/wp-content\/uploads\/2015\/06\/Glad-You-Came-The-Wanted.mp3&quot;,

																&quot;thumb&quot;:&quot;&lt;img width=\&quot;150\&quot; height=\&quot;150\&quot; src=\&quot;images\/album\/album-thumb-40x40.jpg\&quot; alt=\&quot;rock17\&quot; \/&gt;&quot;,

																&quot;name&quot;:&quot;Glad You Came&quot;,

																&quot;url&quot;:&quot;#&quot;,

																&quot;album&quot;:&quot;Happy music day&quot;
															},
															{
																&quot;id&quot;:&quot;album_5&quot;,

																&quot;artist&quot;:&quot;&lt;a href=\&quot;javascript:void(0)\&quot;&gt;Helloween&lt;\/a&gt;&quot;,

																&quot;file&quot;:&quot;http:\/\/wp.nootheme.com\/wemusic\/wp-content\/uploads\/2015\/06\/Forever-And-One-Helloween.mp3&quot;,

																&quot;thumb&quot;:&quot;&lt;img width=\&quot;150\&quot; height=\&quot;150\&quot; src=\&quot;images\/album\/album-thumb-40x40.jpg\&quot; alt=\&quot;rock17\&quot; \/&gt;&quot;,

																&quot;name&quot;:&quot;Forever And One&quot;,

																&quot;url&quot;:&quot;#&quot;,

																&quot;album&quot;:&quot;Happy music day&quot;
															},
															{
																&quot;id&quot;:&quot;album_6&quot;,

																&quot;artist&quot;:&quot;&lt;a href=\&quot;javascript:void(0)\&quot;&gt;Shane Filan&lt;\/a&gt;&quot;,

																&quot;file&quot;:&quot;http:\/\/wp.nootheme.com\/wemusic\/wp-content\/uploads\/2015\/06\/Beatiful-In-White-Shane-Filan.mp3&quot;,

																&quot;thumb&quot;:&quot;&lt;img width=\&quot;150\&quot; height=\&quot;150\&quot; src=\&quot;images\/album\/album-thumb-40x40.jpg\&quot; alt=\&quot;rock17\&quot; \/&gt;&quot;,

																&quot;name&quot;:&quot;Beatiful In White&quot;,

																&quot;url&quot;:&quot;#&quot;,

																&quot;album&quot;:&quot;Happy music day&quot;

															}]' class="add-to-playlist-btn">
															<i class="fa fa-plus"></i> Add to Playlist
														</a>
													</div>
												</figcaption>
											</figure>
										</div>
									</li>
									<li class="col-md-4 col-sm-6">
										<div class="noo_album-container">
											<figure>
												<div class="noo_album-wrap">
													<div class="noo_album-images">
														<a href="#">
															<img width="500" height="700" src="images/album/album-thumb-370x482.jpg" alt="rock16"/>
														</a>
													</div>
												</div>
												<figcaption>
													<div class="noo_album-info">
														<h3 class="noo_album_title">
															<a href="#">Live on Letterman</a>
														</h3>
														<div class="noo_album-category">
															<a href="#">Dance</a>
														</div>
													</div>
													<div class="noo_album-loop-actions">
														<a href="#"><i class="fa fa-link"></i> Detail</a>
														<a href="#" data-songs='[
															{
																&quot;id&quot;:&quot;album_1&quot;,

																&quot;artist&quot;:&quot;&lt;a href=\&quot;javascript:void(0)\&quot;&gt;Maroon 5 ft Wiz Khalifa&lt;\/a&gt;&quot;,
					
																&quot;file&quot;:&quot;http:\/\/wp.nootheme.com\/wemusic\/wp-content\/uploads\/2015\/06\/Payphone-Maroon-5-ft-Wiz-Khalifa.mp3&quot;,

																&quot;thumb&quot;:&quot;&lt;img width=\&quot;150\&quot; height=\&quot;150\&quot; src=\&quot;images\/album\/album-thumb-40x40.jpg\&quot; alt=\&quot;rock16\&quot; \/&gt;&quot;,

																&quot;name&quot;:&quot;Payphone&quot;,

																&quot;url&quot;:&quot;#&quot;,

																&quot;album&quot;:&quot;Live on Letterman&quot;
															},
															{
																&quot;id&quot;:&quot;album_2&quot;,

																&quot;artist&quot;:&quot;&lt;a href=\&quot;javascript:void(0)\&quot;&gt;Engelbert Humperdinck&lt;\/a&gt;&quot;,

																&quot;file&quot;:&quot;http:\/\/wp.nootheme.com\/wemusic\/wp-content\/uploads\/2015\/06\/Quando-Quando-Engelbert-Humperdinck-Engelbert-Humperdinck.mp3&quot;,

																&quot;thumb&quot;:&quot;&lt;img width=\&quot;150\&quot; height=\&quot;150\&quot; src=\&quot;images\/album\/album-thumb-40x40.jpg\&quot; alt=\&quot;rock16\&quot; \/&gt;&quot;,

																&quot;name&quot;:&quot;Quando Quando&quot;,

																&quot;url&quot;:&quot;#&quot;,

																&quot;album&quot;:&quot;Live on Letterman&quot;
															},
															{
																&quot;id&quot;:&quot;album_3&quot;,

																&quot;artist&quot;:&quot;&lt;a href=\&quot;javascript:void(0)\&quot;&gt;Modern Talking&lt;\/a&gt;&quot;,

																&quot;file&quot;:&quot;http:\/\/wp.nootheme.com\/wemusic\/wp-content\/uploads\/2015\/06\/No-Face-No-Name-No-Number-Modern-Talking.mp3&quot;,

																&quot;thumb&quot;:&quot;&lt;img width=\&quot;150\&quot; height=\&quot;150\&quot; src=\&quot;images\/album\/album-thumb-40x40.jpg\&quot; alt=\&quot;rock16\&quot; \/&gt;&quot;,

																&quot;name&quot;:&quot;No Face No Name No Number&quot;,

																&quot;url&quot;:&quot;#&quot;,

																&quot;album&quot;:&quot;Live on Letterman&quot;
															},
															{
																&quot;id&quot;:&quot;album_4&quot;,

																&quot;artist&quot;:&quot;&lt;a href=\&quot;javascript:void(0)\&quot;&gt;The Wanted&lt;\/a&gt;&quot;,

																&quot;file&quot;:&quot;http:\/\/wp.nootheme.com\/wemusic\/wp-content\/uploads\/2015\/06\/Glad-You-Came-The-Wanted.mp3&quot;,

																&quot;thumb&quot;:&quot;&lt;img width=\&quot;150\&quot; height=\&quot;150\&quot; src=\&quot;images\/album\/album-thumb-40x40.jpg\&quot; alt=\&quot;rock16\&quot; \/&gt;&quot;,

																&quot;name&quot;:&quot;Glad You Came&quot;,

																&quot;url&quot;:&quot;#&quot;,

																&quot;album&quot;:&quot;Live on Letterman&quot;
															},
															{
																&quot;id&quot;:&quot;album_5&quot;,

																&quot;artist&quot;:&quot;&lt;a href=\&quot;javascript:void(0)\&quot;&gt;Helloween&lt;\/a&gt;&quot;,

																&quot;file&quot;:&quot;http:\/\/wp.nootheme.com\/wemusic\/wp-content\/uploads\/2015\/06\/Forever-And-One-Helloween.mp3&quot;,

																&quot;thumb&quot;:&quot;&lt;img width=\&quot;150\&quot; height=\&quot;150\&quot; src=\&quot;images\/album\/album-thumb-40x40.jpg\&quot; alt=\&quot;rock16\&quot; \/&gt;&quot;,

																&quot;name&quot;:&quot;Forever And One&quot;,

																&quot;url&quot;:&quot;#&quot;,

																&quot;album&quot;:&quot;Live on Letterman&quot;
															},
															{
																&quot;id&quot;:&quot;album_6&quot;,

																&quot;artist&quot;:&quot;&lt;a href=\&quot;javascript:void(0)\&quot;&gt;Shane Filan&lt;\/a&gt;&quot;,

																&quot;file&quot;:&quot;http:\/\/wp.nootheme.com\/wemusic\/wp-content\/uploads\/2015\/06\/Beatiful-In-White-Shane-Filan.mp3&quot;,

																&quot;thumb&quot;:&quot;&lt;img width=\&quot;150\&quot; height=\&quot;150\&quot; src=\&quot;images\/album\/album-thumb-40x40.jpg\&quot; alt=\&quot;rock16\&quot; \/&gt;&quot;,

																&quot;name&quot;:&quot;Beatiful In White&quot;,

																&quot;url&quot;:&quot;#&quot;,

																&quot;album&quot;:&quot;Live on Letterman&quot;

															}]' class="add-to-playlist-btn">
															<i class="fa fa-plus"></i> Add to Playlist
														</a>
													</div>
												</figcaption>
											</figure>
										</div>
									</li>
									<li class="col-md-4 col-sm-6">
										<div class="noo_album-container">
											<figure>
												<div class="noo_album-wrap">
													<div class="noo_album-images">
														<a href="#">
															<img width="500" height="700" src="images/album/album-thumb-370x482.jpg" alt="rock2"/>
														</a>
													</div>
												</div>
												<figcaption>
													<div class="noo_album-info">
														<h3 class="noo_album_title">
															<a href="#">Hollywood bowl</a>
														</h3>
														<div class="noo_album-category">
															<a href="#">Jazz</a>
														</div>
													</div>
													<div class="noo_album-loop-actions">
														<a href="#"><i class="fa fa-link"></i> Detail</a>
														<a href="#" data-songs='[
															{
																&quot;id&quot;:&quot;album_1&quot;,

																&quot;artist&quot;:&quot;&lt;a href=\&quot;javascript:void(0)\&quot;&gt;Maroon 5 ft Wiz Khalifa&lt;\/a&gt;&quot;,
					
																&quot;file&quot;:&quot;http:\/\/wp.nootheme.com\/wemusic\/wp-content\/uploads\/2015\/06\/Payphone-Maroon-5-ft-Wiz-Khalifa.mp3&quot;,

																&quot;thumb&quot;:&quot;&lt;img width=\&quot;150\&quot; height=\&quot;150\&quot; src=\&quot;images\/album\/album-thumb-40x40.jpg\&quot; alt=\&quot;rock2\&quot; \/&gt;&quot;,

																&quot;name&quot;:&quot;Payphone&quot;,

																&quot;url&quot;:&quot;#&quot;,

																&quot;album&quot;:&quot;Hollywood bowl&quot;
															},
															{
																&quot;id&quot;:&quot;album_2&quot;,

																&quot;artist&quot;:&quot;&lt;a href=\&quot;javascript:void(0)\&quot;&gt;Engelbert Humperdinck&lt;\/a&gt;&quot;,

																&quot;file&quot;:&quot;http:\/\/wp.nootheme.com\/wemusic\/wp-content\/uploads\/2015\/06\/Quando-Quando-Engelbert-Humperdinck-Engelbert-Humperdinck.mp3&quot;,

																&quot;thumb&quot;:&quot;&lt;img width=\&quot;150\&quot; height=\&quot;150\&quot; src=\&quot;images\/album\/album-thumb-40x40.jpg\&quot; alt=\&quot;rock2\&quot; \/&gt;&quot;,

																&quot;name&quot;:&quot;Quando Quando&quot;,

																&quot;url&quot;:&quot;#&quot;,

																&quot;album&quot;:&quot;Hollywood bowl&quot;
															},
															{
																&quot;id&quot;:&quot;album_3&quot;,

																&quot;artist&quot;:&quot;&lt;a href=\&quot;javascript:void(0)\&quot;&gt;Modern Talking&lt;\/a&gt;&quot;,

																&quot;file&quot;:&quot;http:\/\/wp.nootheme.com\/wemusic\/wp-content\/uploads\/2015\/06\/No-Face-No-Name-No-Number-Modern-Talking.mp3&quot;,

																&quot;thumb&quot;:&quot;&lt;img width=\&quot;150\&quot; height=\&quot;150\&quot; src=\&quot;images\/album\/album-thumb-40x40.jpg\&quot; alt=\&quot;rock2\&quot; \/&gt;&quot;,

																&quot;name&quot;:&quot;No Face No Name No Number&quot;,

																&quot;url&quot;:&quot;#&quot;,

																&quot;album&quot;:&quot;Hollywood bowl&quot;
															},
															{
																&quot;id&quot;:&quot;album_4&quot;,

																&quot;artist&quot;:&quot;&lt;a href=\&quot;javascript:void(0)\&quot;&gt;The Wanted&lt;\/a&gt;&quot;,

																&quot;file&quot;:&quot;http:\/\/wp.nootheme.com\/wemusic\/wp-content\/uploads\/2015\/06\/Glad-You-Came-The-Wanted.mp3&quot;,

																&quot;thumb&quot;:&quot;&lt;img width=\&quot;150\&quot; height=\&quot;150\&quot; src=\&quot;images\/album\/album-thumb-40x40.jpg\&quot; alt=\&quot;rock2\&quot; \/&gt;&quot;,

																&quot;name&quot;:&quot;Glad You Came&quot;,

																&quot;url&quot;:&quot;#&quot;,

																&quot;album&quot;:&quot;Hollywood bowl&quot;
															},
															{
																&quot;id&quot;:&quot;album_5&quot;,

																&quot;artist&quot;:&quot;&lt;a href=\&quot;javascript:void(0)\&quot;&gt;Helloween&lt;\/a&gt;&quot;,

																&quot;file&quot;:&quot;http:\/\/wp.nootheme.com\/wemusic\/wp-content\/uploads\/2015\/06\/Forever-And-One-Helloween.mp3&quot;,

																&quot;thumb&quot;:&quot;&lt;img width=\&quot;150\&quot; height=\&quot;150\&quot; src=\&quot;images\/album\/album-thumb-40x40.jpg\&quot; alt=\&quot;rock2\&quot; \/&gt;&quot;,

																&quot;name&quot;:&quot;Forever And One&quot;,

																&quot;url&quot;:&quot;#&quot;,

																&quot;album&quot;:&quot;Hollywood bowl&quot;
															},
															{
																&quot;id&quot;:&quot;album_6&quot;,

																&quot;artist&quot;:&quot;&lt;a href=\&quot;javascript:void(0)\&quot;&gt;Shane Filan&lt;\/a&gt;&quot;,

																&quot;file&quot;:&quot;http:\/\/wp.nootheme.com\/wemusic\/wp-content\/uploads\/2015\/06\/Beatiful-In-White-Shane-Filan.mp3&quot;,

																&quot;thumb&quot;:&quot;&lt;img width=\&quot;150\&quot; height=\&quot;150\&quot; src=\&quot;images\/album\/album-thumb-40x40.jpg\&quot; alt=\&quot;rock2\&quot; \/&gt;&quot;,

																&quot;name&quot;:&quot;Beatiful In White&quot;,

																&quot;url&quot;:&quot;#&quot;,

																&quot;album&quot;:&quot;Hollywood bowl&quot;

															}]' class="add-to-playlist-btn">
															<i class="fa fa-plus"></i> Add to Playlist
														</a>
													</div>
												</figcaption>
											</figure>
										</div>
									</li>
									<li class="col-md-4 col-sm-6">
										<div class="noo_album-container">
											<figure>
												<div class="noo_album-wrap">
													<div class="noo_album-images">
														<a href="#">
															<img width="500" height="700" src="images/album/album-thumb-370x482.jpg" alt="rock3"/>
														</a>
													</div>
												</div>
												<figcaption>
													<div class="noo_album-info">
														<h3 class="noo_album_title">
															<a href="#">Papagayo Beach Club</a>
														</h3>
														<div class="noo_album-category">
															<a href="#">Jazz</a>
														</div>
													</div>
													<div class="noo_album-loop-actions">
														<a href="#"><i class="fa fa-link"></i> Detail</a>
														<a href="#" data-songs='[
															{
																&quot;id&quot;:&quot;album_1&quot;,

																&quot;artist&quot;:&quot;&lt;a href=\&quot;javascript:void(0)\&quot;&gt;Maroon 5 ft Wiz Khalifa&lt;\/a&gt;&quot;,
					
																&quot;file&quot;:&quot;http:\/\/wp.nootheme.com\/wemusic\/wp-content\/uploads\/2015\/06\/Payphone-Maroon-5-ft-Wiz-Khalifa.mp3&quot;,

																&quot;thumb&quot;:&quot;&lt;img width=\&quot;150\&quot; height=\&quot;150\&quot; src=\&quot;images\/album\/album-thumb-40x40.jpg\&quot; alt=\&quot;rock3\&quot; \/&gt;&quot;,

																&quot;name&quot;:&quot;Payphone&quot;,

																&quot;url&quot;:&quot;#&quot;,

																&quot;album&quot;:&quot;Papagayo Beach Club&quot;
															},
															{
																&quot;id&quot;:&quot;album_2&quot;,

																&quot;artist&quot;:&quot;&lt;a href=\&quot;javascript:void(0)\&quot;&gt;Engelbert Humperdinck&lt;\/a&gt;&quot;,

																&quot;file&quot;:&quot;http:\/\/wp.nootheme.com\/wemusic\/wp-content\/uploads\/2015\/06\/Quando-Quando-Engelbert-Humperdinck-Engelbert-Humperdinck.mp3&quot;,

																&quot;thumb&quot;:&quot;&lt;img width=\&quot;150\&quot; height=\&quot;150\&quot; src=\&quot;images\/album\/album-thumb-40x40.jpg\&quot; alt=\&quot;rock3\&quot; \/&gt;&quot;,

																&quot;name&quot;:&quot;Quando Quando&quot;,

																&quot;url&quot;:&quot;#&quot;,

																&quot;album&quot;:&quot;Papagayo Beach Club&quot;
															},
															{
																&quot;id&quot;:&quot;album_3&quot;,

																&quot;artist&quot;:&quot;&lt;a href=\&quot;javascript:void(0)\&quot;&gt;Modern Talking&lt;\/a&gt;&quot;,

																&quot;file&quot;:&quot;http:\/\/wp.nootheme.com\/wemusic\/wp-content\/uploads\/2015\/06\/No-Face-No-Name-No-Number-Modern-Talking.mp3&quot;,

																&quot;thumb&quot;:&quot;&lt;img width=\&quot;150\&quot; height=\&quot;150\&quot; src=\&quot;images\/album\/album-thumb-40x40.jpg\&quot; alt=\&quot;rock3\&quot; \/&gt;&quot;,

																&quot;name&quot;:&quot;No Face No Name No Number&quot;,

																&quot;url&quot;:&quot;#&quot;,

																&quot;album&quot;:&quot;Papagayo Beach Club&quot;
															},
															{
																&quot;id&quot;:&quot;album_4&quot;,

																&quot;artist&quot;:&quot;&lt;a href=\&quot;javascript:void(0)\&quot;&gt;The Wanted&lt;\/a&gt;&quot;,

																&quot;file&quot;:&quot;http:\/\/wp.nootheme.com\/wemusic\/wp-content\/uploads\/2015\/06\/Glad-You-Came-The-Wanted.mp3&quot;,

																&quot;thumb&quot;:&quot;&lt;img width=\&quot;150\&quot; height=\&quot;150\&quot; src=\&quot;images\/album\/album-thumb-40x40.jpg\&quot; alt=\&quot;rock3\&quot; \/&gt;&quot;,

																&quot;name&quot;:&quot;Glad You Came&quot;,

																&quot;url&quot;:&quot;#&quot;,

																&quot;album&quot;:&quot;Papagayo Beach Club&quot;
															},
															{
																&quot;id&quot;:&quot;album_5&quot;,

																&quot;artist&quot;:&quot;&lt;a href=\&quot;javascript:void(0)\&quot;&gt;Helloween&lt;\/a&gt;&quot;,

																&quot;file&quot;:&quot;http:\/\/wp.nootheme.com\/wemusic\/wp-content\/uploads\/2015\/06\/Forever-And-One-Helloween.mp3&quot;,

																&quot;thumb&quot;:&quot;&lt;img width=\&quot;150\&quot; height=\&quot;150\&quot; src=\&quot;images\/album\/album-thumb-40x40.jpg\&quot; alt=\&quot;rock3\&quot; \/&gt;&quot;,

																&quot;name&quot;:&quot;Forever And One&quot;,

																&quot;url&quot;:&quot;#&quot;,

																&quot;album&quot;:&quot;Papagayo Beach Club&quot;
															},
															{
																&quot;id&quot;:&quot;album_6&quot;,

																&quot;artist&quot;:&quot;&lt;a href=\&quot;javascript:void(0)\&quot;&gt;Shane Filan&lt;\/a&gt;&quot;,

																&quot;file&quot;:&quot;http:\/\/wp.nootheme.com\/wemusic\/wp-content\/uploads\/2015\/06\/Beatiful-In-White-Shane-Filan.mp3&quot;,

																&quot;thumb&quot;:&quot;&lt;img width=\&quot;150\&quot; height=\&quot;150\&quot; src=\&quot;images\/album\/rock3.jpg\&quot; alt=\&quot;rock3\&quot; \/&gt;&quot;,

																&quot;name&quot;:&quot;Beatiful In White&quot;,

																&quot;url&quot;:&quot;#&quot;,

																&quot;album&quot;:&quot;Papagayo Beach Club&quot;

															}]' class="add-to-playlist-btn">
															<i class="fa fa-plus"></i> Add to Playlist
														</a>
													</div>
												</figcaption>
											</figure>
										</div>
									</li>
									<li class="col-md-4 col-sm-6">
										<div class="noo_album-container">
											<figure>
												<div class="noo_album-wrap">
													<div class="noo_album-images">
														<a href="#">
															<img width="500" height="700" src="images/album/album-thumb-370x482.jpg" alt="rock4"/>
														</a>
													</div>
												</div>
												<figcaption>
													<div class="noo_album-info">
														<h3 class="noo_album_title">
															<a href="#">Roseland Ballroom</a>
														</h3>
														<div class="noo_album-category">
															<a href="#">Jazz</a>
														</div>
													</div>
													<div class="noo_album-loop-actions">
														<a href="#"><i class="fa fa-link"></i> Detail</a>
														<a href="#" data-songs='[
															{
																&quot;id&quot;:&quot;album_1&quot;,

																&quot;artist&quot;:&quot;&lt;a href=\&quot;javascript:void(0)\&quot;&gt;Maroon 5 ft Wiz Khalifa&lt;\/a&gt;&quot;,
					
																&quot;file&quot;:&quot;http:\/\/wp.nootheme.com\/wemusic\/wp-content\/uploads\/2015\/06\/Payphone-Maroon-5-ft-Wiz-Khalifa.mp3&quot;,

																&quot;thumb&quot;:&quot;&lt;img width=\&quot;150\&quot; height=\&quot;150\&quot; src=\&quot;images\/album\/album-thumb-40x40.jpg\&quot; alt=\&quot;rock4\&quot; \/&gt;&quot;,

																&quot;name&quot;:&quot;Payphone&quot;,

																&quot;url&quot;:&quot;#&quot;,

																&quot;album&quot;:&quot;Roseland Ballroom&quot;
															},
															{
																&quot;id&quot;:&quot;album_2&quot;,

																&quot;artist&quot;:&quot;&lt;a href=\&quot;javascript:void(0)\&quot;&gt;Engelbert Humperdinck&lt;\/a&gt;&quot;,

																&quot;file&quot;:&quot;http:\/\/wp.nootheme.com\/wemusic\/wp-content\/uploads\/2015\/06\/Quando-Quando-Engelbert-Humperdinck-Engelbert-Humperdinck.mp3&quot;,

																&quot;thumb&quot;:&quot;&lt;img width=\&quot;150\&quot; height=\&quot;150\&quot; src=\&quot;images\/album\/album-thumb-40x40.jpg\&quot; alt=\&quot;rock4\&quot; \/&gt;&quot;,

																&quot;name&quot;:&quot;Quando Quando&quot;,

																&quot;url&quot;:&quot;#&quot;,

																&quot;album&quot;:&quot;Roseland Ballroom&quot;
															},
															{
																&quot;id&quot;:&quot;album_3&quot;,

																&quot;artist&quot;:&quot;&lt;a href=\&quot;javascript:void(0)\&quot;&gt;Modern Talking&lt;\/a&gt;&quot;,

																&quot;file&quot;:&quot;http:\/\/wp.nootheme.com\/wemusic\/wp-content\/uploads\/2015\/06\/No-Face-No-Name-No-Number-Modern-Talking.mp3&quot;,

																&quot;thumb&quot;:&quot;&lt;img width=\&quot;150\&quot; height=\&quot;150\&quot; src=\&quot;images\/album\/album-thumb-40x40.jpg\&quot; alt=\&quot;rock4\&quot; \/&gt;&quot;,

																&quot;name&quot;:&quot;No Face No Name No Number&quot;,

																&quot;url&quot;:&quot;#&quot;,

																&quot;album&quot;:&quot;Roseland Ballroom&quot;
															},
															{
																&quot;id&quot;:&quot;album_4&quot;,

																&quot;artist&quot;:&quot;&lt;a href=\&quot;javascript:void(0)\&quot;&gt;The Wanted&lt;\/a&gt;&quot;,

																&quot;file&quot;:&quot;http:\/\/wp.nootheme.com\/wemusic\/wp-content\/uploads\/2015\/06\/Glad-You-Came-The-Wanted.mp3&quot;,

																&quot;thumb&quot;:&quot;&lt;img width=\&quot;150\&quot; height=\&quot;150\&quot; src=\&quot;images\/album\/album-thumb-40x40.jpg\&quot; alt=\&quot;rock4\&quot; \/&gt;&quot;,

																&quot;name&quot;:&quot;Glad You Came&quot;,

																&quot;url&quot;:&quot;#&quot;,

																&quot;album&quot;:&quot;Roseland Ballroom&quot;
															},
															{
																&quot;id&quot;:&quot;album_5&quot;,

																&quot;artist&quot;:&quot;&lt;a href=\&quot;javascript:void(0)\&quot;&gt;Helloween&lt;\/a&gt;&quot;,

																&quot;file&quot;:&quot;http:\/\/wp.nootheme.com\/wemusic\/wp-content\/uploads\/2015\/06\/Forever-And-One-Helloween.mp3&quot;,

																&quot;thumb&quot;:&quot;&lt;img width=\&quot;150\&quot; height=\&quot;150\&quot; src=\&quot;images\/album\/album-thumb-40x40.jpg\&quot; alt=\&quot;rock4\&quot; \/&gt;&quot;,

																&quot;name&quot;:&quot;Forever And One&quot;,

																&quot;url&quot;:&quot;#&quot;,

																&quot;album&quot;:&quot;Roseland Ballroom&quot;
															},
															{
																&quot;id&quot;:&quot;album_6&quot;,

																&quot;artist&quot;:&quot;&lt;a href=\&quot;javascript:void(0)\&quot;&gt;Shane Filan&lt;\/a&gt;&quot;,

																&quot;file&quot;:&quot;http:\/\/wp.nootheme.com\/wemusic\/wp-content\/uploads\/2015\/06\/Beatiful-In-White-Shane-Filan.mp3&quot;,

																&quot;thumb&quot;:&quot;&lt;img width=\&quot;150\&quot; height=\&quot;150\&quot; src=\&quot;images\/album\/album-thumb-40x40.jpg\&quot; alt=\&quot;rock4\&quot; \/&gt;&quot;,

																&quot;name&quot;:&quot;Beatiful In White&quot;,

																&quot;url&quot;:&quot;#&quot;,

																&quot;album&quot;:&quot;Roseland Ballroom&quot;

															}]' class="add-to-playlist-btn">
															<i class="fa fa-plus"></i> Add to Playlist
														</a>
													</div>
												</figcaption>
											</figure>
										</div>
									</li>
									<li class="col-md-4 col-sm-6">
										<div class="noo_album-container">
											<figure>
												<div class="noo_album-wrap">
													<div class="noo_album-images">
														<a href="#">
															<img width="500" height="700" src="images/album/album-thumb-370x482.jpg" alt="rock9"/>
														</a>
													</div>
												</div>
												<figcaption>
													<div class="noo_album-info">
														<h3 class="noo_album_title">
															<a href="#">Happy music day</a>
														</h3>
														<div class="noo_album-category">
															<a href="#">Jazz</a>
														</div>
													</div>
													<div class="noo_album-loop-actions">
														<a href="#"><i class="fa fa-link"></i> Detail</a>
														<a href="#" data-songs='[
															{
																&quot;id&quot;:&quot;album_1&quot;,

																&quot;artist&quot;:&quot;&lt;a href=\&quot;javascript:void(0)\&quot;&gt;Maroon 5 ft Wiz Khalifa&lt;\/a&gt;&quot;,
					
																&quot;file&quot;:&quot;http:\/\/wp.nootheme.com\/wemusic\/wp-content\/uploads\/2015\/06\/Payphone-Maroon-5-ft-Wiz-Khalifa.mp3&quot;,

																&quot;thumb&quot;:&quot;&lt;img width=\&quot;150\&quot; height=\&quot;150\&quot; src=\&quot;images\/album\/album-thumb-40x40.jpg\&quot; alt=\&quot;rock9\&quot; \/&gt;&quot;,

																&quot;name&quot;:&quot;Payphone&quot;,

																&quot;url&quot;:&quot;#&quot;,

																&quot;album&quot;:&quot;Happy music day&quot;
															},
															{
																&quot;id&quot;:&quot;album_2&quot;,

																&quot;artist&quot;:&quot;&lt;a href=\&quot;javascript:void(0)\&quot;&gt;Engelbert Humperdinck&lt;\/a&gt;&quot;,

																&quot;file&quot;:&quot;http:\/\/wp.nootheme.com\/wemusic\/wp-content\/uploads\/2015\/06\/Quando-Quando-Engelbert-Humperdinck-Engelbert-Humperdinck.mp3&quot;,

																&quot;thumb&quot;:&quot;&lt;img width=\&quot;150\&quot; height=\&quot;150\&quot; src=\&quot;images\/album\/album-thumb-40x40.jpg\&quot; alt=\&quot;rock9\&quot; \/&gt;&quot;,

																&quot;name&quot;:&quot;Quando Quando&quot;,

																&quot;url&quot;:&quot;#&quot;,

																&quot;album&quot;:&quot;Happy music day&quot;
															},
															{
																&quot;id&quot;:&quot;album_3&quot;,

																&quot;artist&quot;:&quot;&lt;a href=\&quot;javascript:void(0)\&quot;&gt;Modern Talking&lt;\/a&gt;&quot;,

																&quot;file&quot;:&quot;http:\/\/wp.nootheme.com\/wemusic\/wp-content\/uploads\/2015\/06\/No-Face-No-Name-No-Number-Modern-Talking.mp3&quot;,

																&quot;thumb&quot;:&quot;&lt;img width=\&quot;150\&quot; height=\&quot;150\&quot; src=\&quot;images\/album\/album-thumb-40x40.jpg\&quot; alt=\&quot;rock9\&quot; \/&gt;&quot;,

																&quot;name&quot;:&quot;No Face No Name No Number&quot;,

																&quot;url&quot;:&quot;#&quot;,

																&quot;album&quot;:&quot;Happy music day&quot;
															},
															{
																&quot;id&quot;:&quot;album_4&quot;,

																&quot;artist&quot;:&quot;&lt;a href=\&quot;javascript:void(0)\&quot;&gt;The Wanted&lt;\/a&gt;&quot;,

																&quot;file&quot;:&quot;http:\/\/wp.nootheme.com\/wemusic\/wp-content\/uploads\/2015\/06\/Glad-You-Came-The-Wanted.mp3&quot;,

																&quot;thumb&quot;:&quot;&lt;img width=\&quot;150\&quot; height=\&quot;150\&quot; src=\&quot;images\/album\/album-thumb-40x40.jpg\&quot; alt=\&quot;rock9\&quot; \/&gt;&quot;,

																&quot;name&quot;:&quot;Glad You Came&quot;,

																&quot;url&quot;:&quot;#&quot;,

																&quot;album&quot;:&quot;Happy music day&quot;
															},
															{
																&quot;id&quot;:&quot;album_5&quot;,

																&quot;artist&quot;:&quot;&lt;a href=\&quot;javascript:void(0)\&quot;&gt;Helloween&lt;\/a&gt;&quot;,

																&quot;file&quot;:&quot;http:\/\/wp.nootheme.com\/wemusic\/wp-content\/uploads\/2015\/06\/Forever-And-One-Helloween.mp3&quot;,

																&quot;thumb&quot;:&quot;&lt;img width=\&quot;150\&quot; height=\&quot;150\&quot; src=\&quot;images\/album\/album-thumb-40x40.jpg\&quot; alt=\&quot;rock9\&quot; \/&gt;&quot;,

																&quot;name&quot;:&quot;Forever And One&quot;,

																&quot;url&quot;:&quot;#&quot;,

																&quot;album&quot;:&quot;Happy music day&quot;
															},
															{
																&quot;id&quot;:&quot;album_6&quot;,

																&quot;artist&quot;:&quot;&lt;a href=\&quot;javascript:void(0)\&quot;&gt;Shane Filan&lt;\/a&gt;&quot;,

																&quot;file&quot;:&quot;http:\/\/wp.nootheme.com\/wemusic\/wp-content\/uploads\/2015\/06\/Beatiful-In-White-Shane-Filan.mp3&quot;,

																&quot;thumb&quot;:&quot;&lt;img width=\&quot;150\&quot; height=\&quot;150\&quot; src=\&quot;images\/album\/album-thumb-40x40.jpg\&quot; alt=\&quot;rock9\&quot; \/&gt;&quot;,

																&quot;name&quot;:&quot;Beatiful In White&quot;,

																&quot;url&quot;:&quot;#&quot;,

																&quot;album&quot;:&quot;Happy music day&quot;

															}]' class="add-to-playlist-btn">
															<i class="fa fa-plus"></i> Add to Playlist
														</a>
													</div>
												</figcaption>
											</figure>
										</div>
									</li>
								</ul>
							</div>
							<div class="pagination list-center">
								<span class="page-numbers current">1</span>
								<a class="page-numbers" href="#">2</a>
								<span class="page-numbers dots">…</span>
								<a class="page-numbers" href="#">4</a>
								<a class="next page-numbers" href="#">
									<i class="fa fa-long-arrow-right"></i>
								</a>
							</div>
						</div>
					</div>
				</div>
			</div>
			<?php include("footer.php");?>
		</div>  
	

		<script type='text/javascript' src='http://code.jquery.com/jquery-1.11.3.min.js'></script>
		<script type='text/javascript' src='js/jquery-migrate.min.js'></script>
		<script type='text/javascript' src='js/jquery.themepunch.tools.min.js'></script>
		<script type='text/javascript' src='js/jquery.themepunch.revolution.min.js'></script>
		<script type='text/javascript' src='js/modernizr-2.7.1.min.js'></script>
		<script type='text/javascript' src='js/imagesloaded.pkgd.min.js'></script>
		<script type='text/javascript' src='js/jquery.carouFredSel-6.2.1.js'></script>
		<script type='text/javascript' src='js/jquery.touchSwipe.min.js'></script>
		<script type='text/javascript' src='js/bootstrap.min.js'></script>
		<script type='text/javascript' src='js/hoverIntent-r7.min.js'></script>
		<script type='text/javascript' src='js/superfish-1.7.4.min.js'></script>
		<script type='text/javascript' src='js/main.js'></script>
		<script type='text/javascript' src='js/mediaelement-and-player.js'></script>
		<script type='text/javascript' src='js/player.js'></script>
	</body>
</html>