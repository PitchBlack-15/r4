<!doctype html>
<html lang="en-US">
	<?php include("head.php");?>
	<body class="single-post">
		<!--preloader-->
         <?php include("loader.php");?>
        <!--end preloader-->
		<div class="site">
			<?php include("header.php");?>
			<div class="container-wrap">
				<div class="main-content container">
					<div class="row">
						<div class="noo-main col-md-9">
 							<article class="type-post hentry">	
								<div class="content-featured">
									<div class="content-thumb">
										<img width="1144" height="503" src="images/blog/rules.jpg"/>
									</div>
								</div>
								<div class="content-wrap">
									<div class="content">
										<p>
											Requirements: 
											<br/>
											<br/>
											1. Member should OWN a CIVIC FC.
											<br/>
											<br/>  
											2. Member should reside in Region 4 and Southern Manila area. 
											<br/>
											<br/>
											<br/>
											<br/>

											Everyone SHOULD follow the RULES and REGULATIONS:
											<br/>
											<br/>
											1. FOR SALE items are NOT ALLOWED.
											<br/>
											<br/>
											2. Respect all members within the group.
											<br/>
											<br/>
											3. If there's a conflict within club members, please notify the founder.
											<br/>
											<br/>
											4. YOU are required to leave the group if you're no longer own CIVIC FC e.g. SOLD
											<br/>
											<br/>
											5. You must have a current license. Don't give the police any reason to hassle you or our members.
											<br/>
											<br/>
											6. No drugs, weapons, or anything that would give FC R4 Crew a bad name.
											<br/>
											<br/>
											7. You are hereby pledge to help other members in case they have problem with their car.
											<br/>
											<br/>
											8. NO TO SHOWBOATING. Attempting to post over speeding video/photo is strictly prohibited. If you do it take full responsibility of you action. Sorry but we need to kick you out of the group.
											<br/>
											<br/>
											9. We will not stopping you to join other car clubs.
											<br/>
											<br/>
											10.  It is ENCOURAGED that we attend the Monthly GT. Failure to do so, will be tantamount to an offense.  Three (3) consecutive absence means you are no longer interested with the group and will be subjected to temporary de-activation of your ACTIVE status. Re-instatement will have to be deliberated by the group, with final disposition by the Admin. 
											<br/>
											<br/>
											11. Posts/comments not related to Civic FC will be deleted.
											<br/>
											<br/>
										</p>

							            <form>
											<input id="agreement" type="checkbox" name="agreeCheckbox" value="agreeCheckbox">I Agree. <br>
										</form>

										<div class="entry-tags">
											<span></span>
											<a href="https://docs.google.com/forms/d/e/1FAIpQLSe4At0w-emw1p8q57GdmOzySauRnU5U1s0t-KUqrdCQ0WskkQ/viewform?usp=sf_link" id='regmember' data-text="Register Member"><span>Register as Member</span></a>
											<a href="https://docs.google.com/forms/d/e/1FAIpQLScmCoZPiJ56oS6IpwJeHBufAPYU9LP3obhvogH64jF7gfbvgg/viewform?usp=sf_link" id='regsponsor' data-text="Register Sponsor"><span>Register as Sponsor</span></a>
										</div>
									</div>
								</div>	
							</article>
						</div>  
					</div> 
				</div> 
			</div>  
			<?php include("footer.php");?>
		</div>  
		
		<script type='text/javascript' src='http://code.jquery.com/jquery-1.11.3.min.js'></script>
		<script type='text/javascript' src='js/jquery-migrate.min.js'></script>
		<script type='text/javascript' src='js/jquery.themepunch.tools.min.js'></script>
		<script type='text/javascript' src='js/jquery.themepunch.revolution.min.js'></script>
		<script type='text/javascript' src='js/modernizr-2.7.1.min.js'></script>
		<script type='text/javascript' src='js/imagesloaded.pkgd.min.js'></script>
		<script type='text/javascript' src='js/jquery.carouFredSel-6.2.1.js'></script>
		<script type='text/javascript' src='js/jquery.touchSwipe.min.js'></script>
		<script type='text/javascript' src='js/bootstrap.min.js'></script>
		<script type='text/javascript' src='js/hoverIntent-r7.min.js'></script>
		<script type='text/javascript' src='js/superfish-1.7.4.min.js'></script>
		<script type='text/javascript' src='js/main.js'></script>
		<script type='text/javascript' src='js/mediaelement-and-player.js'></script>
		<script type='text/javascript' src='js/player.js'></script>
		<script>
			jQuery('document').ready(function ($) {
			 	$('#noo-gallery .sliders').carouFredSel({
					infinite: true,
					circular: true,
					auto: false,
					responsive: true,
					prev: {
						button: "#noo-gallery-prev"
						},
						next: {
						button: "#noo-gallery-next"
						},
						pagination: {
						container: "#noo-gallery-pagination"
					}
			  	},{debug : false});
			});

			var chk = document.getElementById("agreement");
			var anchor = document.getElementById("regmember");
			var anchor2 = document.getElementById("regsponsor");

			// anchor.style.display = "none";
			anchor.onclick = function(e){
				e.preventDefault();
			}

			chk.onclick = function(){
				if(chk.checked){
					anchor.style.display = "inline";
					anchor.onclick = "";
				}else{
       			 link.style.display = "none";
				}

			}

		</script>


	</body>
</html>