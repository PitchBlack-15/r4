<header class="noo-header" id="noo-header">
	<div class="navbar-wrapper">
		<div class="navbar navbar-default navbar-static-top">
			<div class="container">
				<div class="navbar-header">
					<h1 class="sr-only">Home</h1>
					<a class="navbar-toggle collapsed" data-toggle="collapse" data-target=".noo-navbar-collapse">
						<span class="sr-only">Navigation</span>
						<i class="fa fa-bars"></i>
					</a>
					<a href="index-parallax.html" class="navbar-brand">
						<img class="noo-logo-img noo-logo-normal" src="images/logo.png" alt="">
						<img class="noo-logo-img noo-logo-floating" src="images/logo.png" alt="">
					</a>
				</div>  
				<nav class="collapse navbar-collapse noo-navbar-collapse">
					<ul class="navbar-nav sf-menu">
						<li class="menu-item-has-children">
							<a href="home.php">Home</a>
						</li>
						<li class="menu-item-has-children">
							<a href="event.php">Events</a>
						</li>
						<!-- <li class="menu-item-has-children">
							<a href="album.php">Galery</a>
						</li> -->
						<li class="menu-item-has-children">
							<a href="sponsor.php">Sponsors</a>
						</li>
						<li><a href="members.php">Admins</a></li>
					<!-- 	<li class="menu-item-has-children">
							<a href="blog.php">Blog</a>
						</li> -->
				
					</ul>
				</nav>  
			</div>  
		</div>  
	</div>
</header>
