<!doctype html>
<html lang="en-US">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0"/>
 		<link rel="shortcut icon" href="images/favicon.png"/>
		<title>Event List | WeMusic - Music Band Event</title>

		<link rel='stylesheet' href='css/settings.css' type='text/css' media='all'/>
		<link rel='stylesheet' href='css/widget-calendar-full.css' type='text/css' media='all'/>
		<link rel='stylesheet' href='css/datepicker.css' type='text/css' media='all'/>
		<link rel='stylesheet' href='css/tribe-events.css' type='text/css' media='all'/>
		<link rel='stylesheet' href='css/tribe-events-pro-theme.css' type='text/css' media='all'/>
		<link rel='stylesheet' href='css/style.css' type='text/css' media='all'/>
		<link rel='stylesheet' href='css/commerce.css' type='text/css' media='all'/>
		<link rel='stylesheet' href='css/font-awesome.min.css' type='text/css' media='all'/>
		<link rel='stylesheet' href='css/jquery.mb.YTPlayer.css' type='text/css' media='all'/>
		<link rel='stylesheet' href='css/owl.carousel.css' type='text/css' media='all'/>
		<link rel='stylesheet' href='css/owl.theme.css' type='text/css' media='all'/>
		<link rel='stylesheet' href='css/nivo-lightbox.css' type='text/css' media='all'/>
		<link rel='stylesheet' href='css/nivo-default.css' type='text/css' media='all'/>
		<link rel='stylesheet' href='css/mediaelementplayer.css' type='text/css' media='all'/>
		<link rel='stylesheet' href='css/layout.css' type='text/css' media='all'/>

		<link rel='stylesheet' href='http://fonts.googleapis.com/css?family=Dosis:100,300,400,700,900,300italic,400italic,700italic,900italic' type='text/css' media='all'/>

		<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
            <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
	</head>
	<body>
		<!--preloader-->
        <div id="loading">
			<div id="loading-center">
				<div id="loading-center-absolute">
					<div class="object"></div>
					<div class="object"></div>
					<div class="object"></div>
					<div class="object"></div>
					<div class="object"></div>
					<div class="object"></div>
					<div class="object"></div>
					<div class="object"></div>
					<div class="object"></div>
					<div class="object"></div>
				</div>
			</div> 
		</div>
        <!--end preloader-->
		<div class="site">
			<?php include("header.php");?>
			<div class="noo-page-heading">
				<div class="container">
					<div class="noo-page-breadcrumb">
						<div class="breadcrumb-wrap">
 							<span><a href="#" class="home">Home</a></span><i>&#047;</i> <span><span>Events</span></span>
 						</div>
					</div>
				</div> 
			</div>
			<div class="noo-tribe-events">
				<div class="container">
					<div class="row">
						<div class="col-md-9">
							<div id="tribe-events" class="tribe-events-uses-geolocation">
								<div class="tribe-clearfix">
 									<div id="tribe-events-bar">
										<form id="tribe-bar-form">
 											<div id="tribe-bar-collapse-toggle">
												Find Events<span class="tribe-bar-toggle-arrow"></span>
											</div>
 											<div id="tribe-bar-views">
												<div class="tribe-bar-views-inner tribe-clearfix">
													<label>View As</label>
													<ul class="tribe-bar-views-list">
														<li class="tribe-bar-views-option tribe-bar-views-option-list tribe-bar-active">
															<a href="#">
																<span class="tribe-icon-list">List </span>
															</a>
														</li>
													</ul>
												</div>
 											</div> 
											<div class="tribe-bar-filters">
												<div class="tribe-bar-filters-inner tribe-clearfix">
													<div class="tribe-bar-date-filter">
														<label class="label-tribe-bar-date">Events From</label>
														<input type="text" name="tribe-bar-date" id="tribe-bar-date" value="" placeholder="Date">
													</div>
													<div class="tribe-bar-search-filter">
														<label class="label-tribe-bar-search">Search</label>
														<input type="text" name="tribe-bar-search" id="tribe-bar-search" value="" placeholder="Search">
													</div>
													<div class="tribe-bar-geoloc-filter">
														<label class="label-tribe-bar-geoloc">Near</label>
														<input type="text" name="tribe-bar-geoloc" id="tribe-bar-geoloc" value="" placeholder="Location">
													</div>
													<div class="tribe-bar-submit">
														<input class="tribe-events-button tribe-no-param" type="submit" name="submit-bar" value="Find Events" enabled/>
													</div>
 												</div>
 											</div> 
										</form>
 									</div> 
 									<div class="tribe-events-list">
 										<div class="tribe-events-loop vcalendar">
											<div class="type-tribe_events tribe-clearfix">
 												<h2 class="tribe-events-list-event-title">
													<a href="#">Fiddler&#8217;s Green Amphitheatre </a>
												</h2>
												<div class="noo-tribe-events-image">
													<span class="noo-attr-style">FREE</span>  
													<div class="tribe-events-event-meta vcard">
														<div class="author location">
 															<div class="time-details">
																<i class="fa fa-calendar"></i>
																<span class="date-start">June 1-8:00 pm</span>
																-
																<span class="date-end">October 31-10:00 pm</span>
															</div>
 															<div class="tribe-events-venue-details">
																<i class="fa fa-map-marker"></i>
																<span class="author"><a href="#">Gramercy Park Hotel</a></span>, 
																<span class="street-address">NewYork</span>
																<a class="tribe-events-gmap" href="http://maps.google.com/maps?f=q&#038;source=s_q&#038;hl=en&#038;geocode=&#038;q=NewYork" title="Click to view a Google Map" target="_blank">+ Google Map</a>
															</div>  
														</div>
													</div> 
 													<div class="tribe-events-event-image">
 														<a href="#">
 															<img width="1280" height="853" src="images/event/event-thumb-870x652.jpg" alt="event5"/>
 														</a>
 													</div>
 												</div>
												<div class="tribe-events-list-event-description">
													<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
													<a href="#" class="tribe-events-read-more">READ MORE</a>
												</div> 
											</div>
											<div class="type-tribe_events tribe-clearfix">
 												<h2 class="tribe-events-list-event-title">
													<a href="#">Editions in the gallery cafe </a>
												</h2>
												<div class="noo-tribe-events-image">
													<span class="noo-attr-style">FREE</span>  
													<div class="tribe-events-event-meta vcard">
														<div class="author location">
 															<div class="time-details">
																<i class="fa fa-calendar"></i>
																<span class="date-start">June 1-9:30 pm</span>
																-
																<span class="date-end">October 31-10:30 pm</span>
															</div>
 															<div class="tribe-events-venue-details">
																<i class="fa fa-map-marker"></i>
																<span class="author"><a href="#">Gramercy Park Hotel</a></span>, 
																<span class="street-address">NewYork</span>
																<a class="tribe-events-gmap" href="http://maps.google.com/maps?f=q&#038;source=s_q&#038;hl=en&#038;geocode=&#038;q=NewYork" title="Click to view a Google Map" target="_blank">+ Google Map</a>
															</div>  
														</div>
													</div> 
 													<div class="tribe-events-event-image">
 														<a href="#">
 															<img width="1280" height="853" src="images/event/event-thumb-870x652.jpg" alt="event3"/>
 														</a>
 													</div>
 												</div>
												<div class="tribe-events-list-event-description">
													<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
													<a href="#" class="tribe-events-read-more">READ MORE</a>
												</div>
											</div>
 											<div class="type-tribe_events tribe-clearfix">
 												<h2 class="tribe-events-list-event-title">
													<a href="#">Ultra Music Festival </a>
												</h2>
												<div class="noo-tribe-events-image">
													<div class="tribe-events-event-meta vcard">
														<div class="author location">
 															<div class="time-details">
																<i class="fa fa-calendar"></i>
																<span class="date-start">June 3-8:00 am</span>
																-
																<span class="date-end">November 30-5:00 pm</span>
															</div>
 															<div class="tribe-events-venue-details">
																<i class="fa fa-map-marker"></i>
																<span class="author"><a href="#">Gramercy Park Hotel</a></span>, 
																<span class="street-address">NewYork</span>
																<a class="tribe-events-gmap" href="http://maps.google.com/maps?f=q&#038;source=s_q&#038;hl=en&#038;geocode=&#038;q=NewYork" title="Click to view a Google Map" target="_blank">+ Google Map</a>
															</div>  
														</div>
													</div> 
 													<div class="tribe-events-event-image">
 														<a href="#">
 															<img width="1280" height="853" src="images/event/event-thumb-870x652.jpg" alt="event13"/>
 														</a>
 													</div>
 												</div>
												<div class="tribe-events-list-event-description">
													<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
													<a href="#" class="tribe-events-read-more">READ MORE</a>
												</div>
											</div>
											<div class="type-tribe_events tribe-clearfix">
 												<h2 class="tribe-events-list-event-title">
													<a href="#">The Gorge Amphitheater </a>
												</h2>
												<div class="noo-tribe-events-image">
													<div class="tribe-events-event-meta vcard">
														<div class="author location">
 															<div class="time-details">
																<i class="fa fa-calendar"></i>
																<span class="date-start">June 5-8:00 pm</span>
																-
																<span class="date-end">October 31-9:00 pm</span>
															</div>
 															<div class="tribe-events-venue-details">
																<i class="fa fa-map-marker"></i>
																<span class="author"><a href="#">Gramercy Park Hotel</a></span>, 
																<span class="street-address">NewYork</span>
																<a class="tribe-events-gmap" href="http://maps.google.com/maps?f=q&#038;source=s_q&#038;hl=en&#038;geocode=&#038;q=NewYork" title="Click to view a Google Map" target="_blank">+ Google Map</a>
															</div>  
														</div>
													</div> 
 													<div class="tribe-events-event-image">
 														<a href="#">
 															<img width="1280" height="853" src="images/event/event-thumb-870x652.jpg" alt="event10"/>
 														</a>
 													</div>
 												</div>
												<div class="tribe-events-list-event-description">
													<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
													<a href="#" class="tribe-events-read-more">READ MORE</a>
												</div>
											</div>
 										</div>
										<div class="pagination list-center">
											<span class="page-numbers current">1</span>
											<a class="page-numbers" href="#">2</a>
											<span class="page-numbers dots">…</span>
											<a class="page-numbers" href="#">4</a>
											<a class="next page-numbers" href="#">
												<i class="fa fa-long-arrow-right"></i>
											</a>
										</div>
										<br />
									</div>
								</div>
							</div> 
 						</div>
						<div class="col-md-3 sidebar-event">
							<div class="widget widget_calendar">
								<div id="calendar_wrap">
									<table id="wp-calendar">
										<caption>October 2015</caption>
										<thead>
											<tr>
												<th scope="col" title="Monday">M</th>
												<th scope="col" title="Tuesday">T</th>
												<th scope="col" title="Wednesday">W</th>
												<th scope="col" title="Thursday">T</th>
												<th scope="col" title="Friday">F</th>
												<th scope="col" title="Saturday">S</th>
												<th scope="col" title="Sunday">S</th>
											</tr>
										</thead>
										<tfoot>
											<tr>
												<td colspan="3"><a href="#" id="prev">&nbsp;</a></td>
												<td class="pad">&nbsp;</td>
												<td colspan="3"><a href="#" id="next">&nbsp;</a></td>
											</tr>
										</tfoot>
										<tbody>
											<tr>
												<td colspan="3" class="pad">&nbsp;</td>
												<td id="today">1</td>
												<td>2</td>
												<td>3</td>
												<td>4</td>
											</tr>
											<tr>
												<td>5</td>
												<td>6</td>
												<td>7</td>
												<td>8</td>
												<td>9</td>
												<td>10</td>
												<td>11</td>
											</tr>
											<tr>
												<td>12</td>
												<td>13</td>
												<td>14</td>
												<td>15</td>
												<td>16</td>
												<td>17</td>
												<td>18</td>
											</tr>
											<tr>
												<td>19</td>
												<td>20</td>
												<td>21</td>
												<td>22</td>
												<td>23</td>
												<td>24</td>
												<td>25</td>
											</tr>
											<tr>
												<td>26</td>
												<td>27</td>
												<td>28</td>
												<td>29</td>
												<td>30</td>
												<td>31</td>
											<td class="pad" colspan="1">&nbsp;</td>
											</tr>
										</tbody>
									</table>
								</div>
							</div>
							<div class="widget widget_noo_request_information">
								<h4 class="widget-title">request information</h4>
								<div class="noo_request_information">
									<i class="fa fa-envelope-o icon-request"></i>
									<p>Want more information about one of our featured events?</p>
									<span>Let&#039;s ask us for free!</span>
									<a class="request" href="#">REQUEST INFO<i class="fa fa-long-arrow-right"></i></a>
								</div>
							</div>
						</div>
					</div>
				</div>  
			</div> 
			<?php include("footer.php");?>
		</div>  
		

		<script type='text/javascript' src='http://code.jquery.com/jquery-1.11.3.min.js'></script>
		<script type='text/javascript' src='js/jquery-migrate.min.js'></script>
		<script type='text/javascript' src='js/jquery.themepunch.tools.min.js'></script>
		<script type='text/javascript' src='js/jquery.themepunch.revolution.min.js'></script>
		<script type='text/javascript' src='js/modernizr-2.7.1.min.js'></script>
		<script type='text/javascript' src='js/imagesloaded.pkgd.min.js'></script>
		<script type='text/javascript' src='js/jquery.carouFredSel-6.2.1.js'></script>
		<script type='text/javascript' src='js/jquery.touchSwipe.min.js'></script>
		<script type='text/javascript' src='js/bootstrap.min.js'></script>
		<script type='text/javascript' src='js/hoverIntent-r7.min.js'></script>
		<script type='text/javascript' src='js/superfish-1.7.4.min.js'></script>
		<script type='text/javascript' src='js/main.js'></script>
		<script type='text/javascript' src='js/mediaelement-and-player.js'></script>
		<script type='text/javascript' src='js/player.js'></script>
		<script type='text/javascript' src='js/bootstrap-datepicker.min.js'></script>
		<script>
            jQuery(document).ready(function(){
                jQuery('#tribe-bar-date').datepicker();
            });
        </script>
	</body>
</html>