<!doctype html>
<html lang="en-US">
	<?php include("head.php");?>
	<body class="page-menu-transparent">
		<!--preloader-->
        <?php include("loader.php");?>
        <!--end preloader-->
		<div class="site">
			<?php include("header.php");?>
			<div class="container-wrap">
				<div class="main-content container-fullwidth">
					<div class="row row-fluid">
						<div class="nocontainer">
							<div class="col-sm-12">
								<div class="noo-countdown">
									<ul class="full-background">
										<li style="background-image: url('images/sliderbackground/slidersponsor.jpg')"></li>
										<li style="background-image: url('images/sliderbackground/slidersolenand.jpg')"></li>
										<li style="background-image: url('images/sliderbackground/slidertagaytay.jpg')"></li>
										<li style="background-image: url('images/sliderbackground/sliderfunrun.jpg')"></li>
									</ul>

									<div id="large-header" class="large-header">
										<canvas id="demo-canvas"></canvas>
									</div>
									<div class="overlay_parallax"></div>
									<div class="noo-countdown-content">
										<div class="container">
											<br><br>
											<h2>FCR4 crew April GT!</h2>
											
											<br><br><br><br><br><br>
							 				<div id="defaultCountdown"></div>
											<div class="noo-countdown-footer">
												<a href="rules-and-regulation.php"><span>Join Us Now!</span></a>	
												<p>Southern Manila.Cavite.Laguna.Batangas.Rizal.Quezon</p>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>


					<div class="row parallax row-fluid home-upcoming-event">
						<div class="overlay_parallax"></div>
						<div class="container">
							<div class="row">
								<div class="col-sm-12">
									<div class="noo-shortcode-events">
										<h2 class="sh-event-title">
											upcoming <span>events</span>
										</h2>
										<p class="sh-ds">
											<!-- Get ready for our exciting monthly and mini GT. -->
										</p>
										<div class="noo-sh-event-content">
											<div class="noo-sh-list-event">
												<span class="entry-date">
												30 <span class="month">April </span>
												</span>
												<div class="noo-thumbnail thumb-1"></div>
												<div class="noo-shevent-content">
													<h4><a href="#">April GT</a></h4>
													<div class="sh-meta">
														<span class="sh-date">
															<i class="fa fa-clock-o"></i>
															<span class="date-start dtstart">
																April 30 8:00 am
															</span>
															-
															<span class="date-end dtend">
																.... <!-- March 30-5:00 pm -->
															</span>
														</span>
														<span class="sh-address">
															<i class="fa fa-map-marker"></i>
															Batangas province
														</span>
													</div>
													<div class="sh-excerpt">
														<p>
															<!-- We are going to have a photoshoot and raffle.  -->
														</p>
													</div>
												</div>
											</div>
											<div class="noo-view-event">
												<a href="event.html">View all events</a>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>

					<div class="row row-fluid home-successful-event">
						<div class="container">
							<div class="row">
								<div class="col-sm-12">
									<div class="noo-shortcode-events grid">
										<div class="noo-grid-header-events">
											<span class="icon">
												<i class="fa fa-calendar"></i>
											</span>
											<h2 class="sh-event-title">
												Successful events
											</h2>
											<p class="sh-ds">
												Catch up the most highlighted moments of our successful events.
											</p>
										</div>
										<div class="noo-sh-event-content row">
										<!-- start -->
											<div class="col-md-4 col-sm-6">
												<div class="noo-sh-grid-event">
													<div class="noo-thumbnail">
														<img width="970" height="647" src="images/event/2ndgt.jpg" alt="blog21"/>
													</div>
													<div class="noo-shevent-content">
														<h4><a href="https://www.facebook.com/media/set/?set=oa.1342620719134225&type=3">February GT</a></h4>
														<div class="sh-meta">
															<span class="sh-time-event">
																<i class="fa fa-clock-o"></i>
																<span class="date-start dtstart">February 19-8:00 am</span>
																-
																<span class="date-end dtend">pm</span>
															</span>
															<span class="sh-address">
																<i class="fa  fa-map-marker"></i>
																Cavite
															</span>
														</div>
													</div>
												</div>
											</div>
										<!-- End -->
											<!-- start -->
											<div class="col-md-4 col-sm-6">
												<div class="noo-sh-grid-event">
													<div class="noo-thumbnail">
														<img width="970" height="647" src="images/event/1stgt.jpg" alt="blog21"/>
													</div>
													<div class="noo-shevent-content">
														<h4><a href="https://www.facebook.com/media/set/?set=oa.1300686176661013&type=3">January GT</a></h4>
														<div class="sh-meta">
															<span class="sh-time-event">
																<i class="fa fa-clock-o"></i>
																<span class="date-start dtstart">January 15-8:00 am</span>
																-
																<span class="date-end dtend">pm</span>
															</span>
															<span class="sh-address">
																<i class="fa  fa-map-marker"></i>
																 Solenad 3, Nuvali
															</span>
														</div>
													</div>
												</div>
											</div>
										<!-- End -->
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>

					<div class="row row-fluid home-album">
						<div class="nocontainer">
							<div class="col-sm-12">
								<div class="wrap">
									<div class="container">
										<div class="noo-grid-header-events header-featured-albums">
											<span class="icon">
												<i class="fa fa-file-image-o"></i>
											</span>
											<h2 class="sh-event-title">
												Featured Members
											</h2>
											<!-- <p class="sh-ds">
												Born to make you happy! By searching our latest premium albums, you will have a lot of funs
											</p> -->
										</div>
									</div>
									<ul class="clearfix noo-featured-albums">

										<li>
											<div class="sh-featured-albumns-item">
												<!-- <img width="500" height="700" src="images/album/album-thumb-316x411.jpg" alt="rock13"/> -->
												<blockquote class="instagram-media" data-instgrm-version="7" style=" background:#FFF; border:0; border-radius:3px; box-shadow:0 0 1px 0 rgba(0,0,0,0.5),0 1px 10px 0 rgba(0,0,0,0.15); margin: 1px; max-width:658px; padding:0; width:99.375%; width:-webkit-calc(100% - 2px); width:calc(100% - 2px);"><div style="padding:8px;"> <div style=" background:#F8F8F8; line-height:0; margin-top:40px; padding:37.5% 0; text-align:center; width:100%;"> <div style=" background:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACwAAAAsCAMAAAApWqozAAAABGdBTUEAALGPC/xhBQAAAAFzUkdCAK7OHOkAAAAMUExURczMzPf399fX1+bm5mzY9AMAAADiSURBVDjLvZXbEsMgCES5/P8/t9FuRVCRmU73JWlzosgSIIZURCjo/ad+EQJJB4Hv8BFt+IDpQoCx1wjOSBFhh2XssxEIYn3ulI/6MNReE07UIWJEv8UEOWDS88LY97kqyTliJKKtuYBbruAyVh5wOHiXmpi5we58Ek028czwyuQdLKPG1Bkb4NnM+VeAnfHqn1k4+GPT6uGQcvu2h2OVuIf/gWUFyy8OWEpdyZSa3aVCqpVoVvzZZ2VTnn2wU8qzVjDDetO90GSy9mVLqtgYSy231MxrY6I2gGqjrTY0L8fxCxfCBbhWrsYYAAAAAElFTkSuQmCC); display:block; height:44px; margin:0 auto -44px; position:relative; top:-22px; width:44px;"></div></div><p style=" color:#c9c8cd; font-family:Arial,sans-serif; font-size:14px; line-height:17px; margin-bottom:0; margin-top:8px; overflow:hidden; padding:8px 0 7px; text-align:center; text-overflow:ellipsis; white-space:nowrap;"><a href="https://www.instagram.com/p/BRbC3-uBSTi/" style=" color:#c9c8cd; font-family:Arial,sans-serif; font-size:14px; font-style:normal; font-weight:normal; line-height:17px; text-decoration:none;" target="_blank">A post shared by FC-R4 Crew (@fcr4crew)</a> on <time style=" font-family:Arial,sans-serif; font-size:14px; line-height:17px;" datetime="2017-03-09T15:34:34+00:00">Mar 9, 2017 at 7:34am PST</time></p></div></blockquote> <script async defer src="//platform.instagram.com/en_US/embeds.js"></script>

												<div class="sh-top">
													<h3 class="product_title">
														<a href="#">Crew of the week</a>
													</h3>
												</div>
												<div class="sh-bottom">
													<div class="shop-info">
														<h3 class="product_title">
															<a href="#">Owner: @e_sayo</a>
														</h3>
														<!-- <div class="product-category">
															<a href="#">Rock</a>
														</div> -->
													</div>
												</div>
											</div>
										</li>
									<!-- 	end -->


										<!-- start -->
										<li>
											<div class="sh-featured-albumns-item">
												<!-- <img width="500" height="700" src="images/album/album-thumb-316x411.jpg" alt="rock13"/> -->
												<blockquote class="instagram-media" data-instgrm-version="7" style=" background:#FFF; border:0; border-radius:3px; box-shadow:0 0 1px 0 rgba(0,0,0,0.5),0 1px 10px 0 rgba(0,0,0,0.15); margin: 1px; max-width:658px; padding:0; width:99.375%; width:-webkit-calc(100% - 2px); width:calc(100% - 2px);"><div style="padding:8px;"> <div style=" background:#F8F8F8; line-height:0; margin-top:40px; padding:33.37962962962963% 0; text-align:center; width:100%;"> <div style=" background:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACwAAAAsCAMAAAApWqozAAAABGdBTUEAALGPC/xhBQAAAAFzUkdCAK7OHOkAAAAMUExURczMzPf399fX1+bm5mzY9AMAAADiSURBVDjLvZXbEsMgCES5/P8/t9FuRVCRmU73JWlzosgSIIZURCjo/ad+EQJJB4Hv8BFt+IDpQoCx1wjOSBFhh2XssxEIYn3ulI/6MNReE07UIWJEv8UEOWDS88LY97kqyTliJKKtuYBbruAyVh5wOHiXmpi5we58Ek028czwyuQdLKPG1Bkb4NnM+VeAnfHqn1k4+GPT6uGQcvu2h2OVuIf/gWUFyy8OWEpdyZSa3aVCqpVoVvzZZ2VTnn2wU8qzVjDDetO90GSy9mVLqtgYSy231MxrY6I2gGqjrTY0L8fxCxfCBbhWrsYYAAAAAElFTkSuQmCC); display:block; height:44px; margin:0 auto -44px; position:relative; top:-22px; width:44px;"></div></div><p style=" color:#c9c8cd; font-family:Arial,sans-serif; font-size:14px; line-height:17px; margin-bottom:0; margin-top:8px; overflow:hidden; padding:8px 0 7px; text-align:center; text-overflow:ellipsis; white-space:nowrap;"><a href="https://www.instagram.com/p/BRF0XqWBMl-/" style=" color:#c9c8cd; font-family:Arial,sans-serif; font-size:14px; font-style:normal; font-weight:normal; line-height:17px; text-decoration:none;" target="_blank">A post shared by FC-R4 Crew (@fcr4crew)</a> on <time style=" font-family:Arial,sans-serif; font-size:14px; line-height:17px;" datetime="2017-03-01T09:43:46+00:00">Mar 1, 2017 at 1:43am PST</time></p></div></blockquote> <script async defer src="//platform.instagram.com/en_US/embeds.js"></script>

												<div class="sh-top">
													<h3 class="product_title">
														<a href="#">Crew of the week</a>
													</h3>
												</div>
												<div class="sh-bottom">
													<div class="shop-info">
														<h3 class="product_title">
															<a href="#">Owner: @nick28drag76</a>
														</h3>
														<!-- <div class="product-category">
															<a href="#">Rock</a>
														</div> -->
													</div>
												</div>
											</div>
										</li>
									<!-- 	end -->


									<!-- start -->
										<li>
											<div class="sh-featured-albumns-item">
												<!-- <img width="500" height="700" src="images/album/album-thumb-316x411.jpg" alt="rock13"/> -->
												<blockquote class="instagram-media" data-instgrm-version="7" style=" background:#FFF; border:0; border-radius:3px; box-shadow:0 0 1px 0 rgba(0,0,0,0.5),0 1px 10px 0 rgba(0,0,0,0.15); margin: 1px; max-width:658px; padding:0; width:99.375%; width:-webkit-calc(100% - 2px); width:calc(100% - 2px);"><div style="padding:8px;"> <div style=" background:#F8F8F8; line-height:0; margin-top:40px; padding:29.095477386934675% 0; text-align:center; width:100%;"> <div style=" background:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACwAAAAsCAMAAAApWqozAAAABGdBTUEAALGPC/xhBQAAAAFzUkdCAK7OHOkAAAAMUExURczMzPf399fX1+bm5mzY9AMAAADiSURBVDjLvZXbEsMgCES5/P8/t9FuRVCRmU73JWlzosgSIIZURCjo/ad+EQJJB4Hv8BFt+IDpQoCx1wjOSBFhh2XssxEIYn3ulI/6MNReE07UIWJEv8UEOWDS88LY97kqyTliJKKtuYBbruAyVh5wOHiXmpi5we58Ek028czwyuQdLKPG1Bkb4NnM+VeAnfHqn1k4+GPT6uGQcvu2h2OVuIf/gWUFyy8OWEpdyZSa3aVCqpVoVvzZZ2VTnn2wU8qzVjDDetO90GSy9mVLqtgYSy231MxrY6I2gGqjrTY0L8fxCxfCBbhWrsYYAAAAAElFTkSuQmCC); display:block; height:44px; margin:0 auto -44px; position:relative; top:-22px; width:44px;"></div></div><p style=" color:#c9c8cd; font-family:Arial,sans-serif; font-size:14px; line-height:17px; margin-bottom:0; margin-top:8px; overflow:hidden; padding:8px 0 7px; text-align:center; text-overflow:ellipsis; white-space:nowrap;"><a href="https://www.instagram.com/p/BQy4TlqB9H6/" style=" color:#c9c8cd; font-family:Arial,sans-serif; font-size:14px; font-style:normal; font-weight:normal; line-height:17px; text-decoration:none;" target="_blank">A post shared by FC-R4 Crew (@fcr4crew)</a> on <time style=" font-family:Arial,sans-serif; font-size:14px; line-height:17px;" datetime="2017-02-22T01:12:35+00:00">Feb 21, 2017 at 5:12pm PST</time></p></div></blockquote> <script async defer src="//platform.instagram.com/en_US/embeds.js"></script>

												<div class="sh-top">
													<h3 class="product_title">
														<a href="#">Crew of the week</a>
													</h3>
												</div>
												<div class="sh-bottom">
													<div class="shop-info">
														<h3 class="product_title">
															<a href="#">Owner: #0006</a>
														</h3>
														<!-- <div class="product-category">
															<a href="#">Rock</a>
														</div> -->
													</div>
												</div>
											</div>
										</li>
									<!-- 	end -->
									</ul>
								</div>
							</div>
						</div>
					</div>
<!-- 					<div class="row row-fluid home-news">
						<div class="container">
							<div class="row">
								<div class="col-sm-12">
									<div class="noo-grid-header-events header-news">
										<span class="icon">
											<i class="fa fa-file-image-o"></i>
										</span>
										<h2 class="sh-event-title">News and Updates</h2>
										<p class="sh-ds">
											We create posts and news with useful information for event overview, tips and trends, highlighted moments to give you the best visualization of what we have done over time.
										</p>
									</div>
									<ul class="noo_news_blog">
								
										<li>
											<div class="noo-sh-thumbail">
												<div class="shthumbail">
													<img width="600" height="450" src="images/blog/blog-thumb-540x360.jpg" alt="blog14"/>
												</div>
											</div>
											<div class="noo-sh-blog-content">
												<h3><a href="#">Why we create music</a></h3>
												<p class="content-meta">
													<span>
														<i class="fa fa-calendar"></i>
														<time class="entry-date" datetime="2015-05-28T06:51:33+00:00">
															May 28th, 2015
														</time>
													</span>
													<span>
														<i class="fa fa-comments-o"></i>
														<a href="#" class="meta-comments"> 0</a>
													</span>
													<span><i class="fa fa-eye"></i>365</span>
												</p>
												<p>
													Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi
												</p>
												<a class="read-more" href="#">Continue Reading...</a>
											</div>
										</li>
										
									</ul>
								</div>
							</div>
						</div>
					</div> -->
					<div class="row row-fluid home-go-top">
						<div class="nocontainer">
							<div class="col-sm-12">
								<div class="noo-line">
									<i class="go-to-top fa fa-angle-up"></i>
								</div>
							</div>
						</div>
					</div>
				</div> 
			</div> 
 			<?php include("footer.php");?>
		</div>  

		<script type='text/javascript' src='http://code.jquery.com/jquery-1.11.3.min.js'></script>
		<script type='text/javascript' src='js/jquery-migrate.min.js'></script>
		<script type='text/javascript' src='js/jquery.themepunch.tools.min.js'></script>
		<script type='text/javascript' src='js/jquery.themepunch.revolution.min.js'></script>
		<script type='text/javascript' src='js/modernizr-2.7.1.min.js'></script>
		<script type='text/javascript' src='js/imagesloaded.pkgd.min.js'></script>
		<script type='text/javascript' src='js/jquery.carouFredSel-6.2.1.js'></script>
		<script type='text/javascript' src='js/jquery.touchSwipe.min.js'></script>
		<script type='text/javascript' src='js/bootstrap.min.js'></script>
		<script type='text/javascript' src='js/hoverIntent-r7.min.js'></script>
		<script type='text/javascript' src='js/superfish-1.7.4.min.js'></script>
		<script type='text/javascript' src='js/main.js'></script>
		<script type='text/javascript' src='js/mediaelement-and-player.js'></script>
		<script type='text/javascript' src='js/player.js'></script>
		<script type='text/javascript' src='js/jquery.plugin.min.js'></script>
		<script type='text/javascript' src='js/jquery.countdown.min.js'></script>
		<script type='text/javascript' src='js/TweenLite.min.js'></script>
		<script type='text/javascript' src='js/EasePack.min.js'></script>
		<script type='text/javascript' src='js/rAF.js'></script>
		<script type='text/javascript' src='js/effect.js'></script>
		<script type='text/javascript' src='js/jquery.parallax.js'></script>
		<script type='text/javascript' src='js/owl.carousel.min.js'></script>

		<script type="text/javascript">
	        var $height_w   = jQuery(window).height();
	        jQuery('.noo-countdown').css('height',$height_w+'px');
            jQuery(window).resize(function(){
                var $height_w = jQuery(window).height();
                jQuery('.noo-countdown').css('height',$height_w+'px');
            });
	        jQuery(function () {   
	        	jQuery('.full-background li:first-child').show();
                var myVar = '';
                clearInterval(myVar);
                myVar = setInterval(function(){
                    jQuery('.full-background li:first-child').fadeOut(1200).next('li').fadeIn(1200).end().appendTo('.full-background');
                },3500);
	            

	        	 
	            austDay = new Date(2017,  3-1 ,  26, 8);
	            jQuery('#defaultCountdown').countdown({until: austDay});
	            jQuery('#year').text(austDay.getFullYear());
	        });
	    </script>
	</body>
</html>