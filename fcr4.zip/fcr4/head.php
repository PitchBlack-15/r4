<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0"/>

	<meta http-equiv="cache-control" content="max-age=0" />
	<meta http-equiv="cache-control" content="no-cache" />
	<meta http-equiv="expires" content="0" />
	<meta http-equiv="expires" content="Tue, 01 Jan 1980 1:00:00 GMT" />
	<meta http-equiv="pragma" content="no-cache" />
	<meta property="og:title" content="Civic 2016 car club from Philippines Region 4 " />
	<meta property="og:image" content="http://www.fcr4crew.com/images/logo.jpg">
	<meta property="og:url" content="http://www.fcr4crew.com/">
	<meta property="og:image:width" content="200" />
	<meta property="og:image:height" content="200" />
	
	<link rel="image_src" href="http://www.fcr4crew.com/images/logo.jpg"/>
	<!-- <link rel="shortcut icon" href="images/favicon.png"/> -->
	<link rel="icon" href="logo.ico" type="images/x-icon">

	<link rel='stylesheet' href='css/bootstrap.min.css' type='text/css' media='all'/>
	<link rel='stylesheet' href='css/settings.css' type='text/css' media='all'/>
	<link rel='stylesheet' href='css/widget-calendar-full.css' type='text/css' media='all'/>
	<link rel='stylesheet' href='css/style.css' type='text/css' media='all'/>
	<link rel='stylesheet' href='css/commerce.css' type='text/css' media='all'/>
	<link rel='stylesheet' href='css/font-awesome.min.css' type='text/css' media='all'/>
	<link rel='stylesheet' href='css/jquery.mb.YTPlayer.css' type='text/css' media='all'/>
	<link rel='stylesheet' href='css/owl.carousel.css' type='text/css' media='all'/>
	<link rel='stylesheet' href='css/owl.theme.css' type='text/css' media='all'/>
	<link rel='stylesheet' href='css/nivo-lightbox.css' type='text/css' media='all'/>
	<link rel='stylesheet' href='css/nivo-default.css' type='text/css' media='all'/>
	<link rel='stylesheet' href='css/mediaelementplayer.css' type='text/css' media='all'/>
	<link rel='stylesheet' href='css/layout.css' type='text/css' media='all'/>
	<link rel='stylesheet' href='http://fonts.googleapis.com/css?family=Dosis:100,300,400,700,900,300italic,400italic,700italic,900italic' type='text/css' media='all'/>
	<meta name="google-site-verification" content="AU8QGQQ_HxGFyiyae-Cu-ochBBd66CQune7PfI3xmQc" />
	<title>FCR4 Crew | Region 4 - 2016 Civic Car Club</title>
	
        <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
            <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
</head>