<!doctype html>
<html lang="en-US">
	<?php include("head.php");?>
	<body>
		<!--preloader-->
        <?php include("loader.php");?>
        <!--end preloader-->
		<div class="site">
			<?php include("header.php");?>
			<!-- <div class="noo-page-heading">
				<div class="container">
					<div class="noo-page-breadcrumb">
						<div class="breadcrumb-wrap">
 							<span>Our Trusted Sponsors</span>
 						</div>
					</div>
				</div> 
			</div> -->
			<div class="container-wrap">
				<div class="container">
					<div class="row">
						<div class="col-md-12">
							<div class="commerce-content commerce">
								
								<ul class="products row">
									<li class="col-md-6 col-sm-12 product">
										<div class="product-container">
											<figure>
												<div class="noo-product-thumbnail">
													<a href="#">
														<img height="1000" width="1000" src="images/sponsor/reflectionscarcare.jpg" />
													</a>
												</div>
												
												<figcaption>
													<h3 class="product_title">
														<a href="#">Reflections Car Care</a>
													</h3>
													<span class="price">
														<span class="amount">10% discount on products and services to valid member of the group with club/org stickers only.  </span>
													</span>
												</figcaption>
											</figure>
										</div>
									</li>

									<li class="col-md-6 col-sm-12 product">
										<div class="product-container">
											<figure>
												<div class="noo-product-thumbnail">
													<a href="#">
														<img height="1000" width="1000" src="images/sponsor/transtectGC.jpg" />
													</a>
												</div>
												
												<figcaption>
													<h3 class="product_title">
														<a href="#">Transtech GC</a>
													</h3>
													<span class="price">
														
													</span>
													<span class="price">
														<span class="amount">15% to 40% discount to members with logo and badge!. Discount rate varies and depending on item.</span>
													</span>
													
												</figcaption>
											</figure>
										</div>
									</li>
									<li class="col-md-6 col-sm-12 product">
										<div class="product-container">
											<figure>
												<div class="noo-product-thumbnail">
													<a href="#">
														<img height="1000" width="1000" src="images/sponsor/notorious.jpg" />
													</a>
												</div>
												
												<figcaption>
													<h3 class="product_title">
														<a href="#">Notorious Motorsports</a>
													</h3>
												
													<span class="price">
														<span class="amount">Enjoy 10% discount to members with logo and badge!</span>
												
													</span>
											
												</figcaption>
											</figure>
										</div>
									</li>
									<li class="col-md-6 col-sm-12 product">
										<div class="product-container">
											<figure>
												<div class="noo-product-thumbnail">
													<a href="#">
														<img height="1000" width="1000" src="images/sponsor/lowconcept.jpg" />
													</a>
												</div>
												
												<figcaption>
													<h3 class="product_title">
														<a href="#">Team LowConcept</a>
													</h3>
													<span class="price">
														<span class="amount">Discounted price for their services</span>
													</span>
												</figcaption>
											</figure>
										</div>
									</li>
									<li class="col-md-6 col-sm-12 product">
										<div class="product-container">
											<figure>
												<div class="noo-product-thumbnail">
													<a href="#">
														<img height="1000" width="1000" src="images/sponsor/HondaAlabang.jpg"/>
													</a>
												</div>
												
												<figcaption>
													<h3 class="product_title">
														<a href="#">Honda Alabang</a>
													</h3>	
													<span class="price">
														<span class="amount">Enjoy 10% discount on all accessories to members with logo and badge!</span>
													</span>
													
												</figcaption>
											</figure>
										</div>
									</li>
									<li class="col-md-6 col-sm-12 product">
										<div class="product-container">
											<figure>
												<div class="noo-product-thumbnail">
													<a href="#">
														<img height="1000" width="1000" src="images/sponsor/sd3computer.jpg" />
													</a>
												</div>
												
												<figcaption>
													<h3 class="product_title">
														<a href="#">SD3 Computer Services</a>
													</h3>
													
													<span class="price">
														<span class="amount">Special Discount to members with logo and badge! </span>
													</span>
													
												</figcaption>
											</figure>
										</div>
									</li>
									
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div> 
			<?php include("footer.php");?>  
		</div>  

		<script type='text/javascript' src='http://code.jquery.com/jquery-1.11.3.min.js'></script>
		<script type='text/javascript' src='js/jquery-migrate.min.js'></script>
		<script type='text/javascript' src='js/jquery.themepunch.tools.min.js'></script>
		<script type='text/javascript' src='js/jquery.themepunch.revolution.min.js'></script>
		<script type='text/javascript' src='js/modernizr-2.7.1.min.js'></script>
		<script type='text/javascript' src='js/imagesloaded.pkgd.min.js'></script>
		<script type='text/javascript' src='js/jquery.carouFredSel-6.2.1.js'></script>
		<script type='text/javascript' src='js/jquery.touchSwipe.min.js'></script>
		<script type='text/javascript' src='js/bootstrap.min.js'></script>
		<script type='text/javascript' src='js/hoverIntent-r7.min.js'></script>
		<script type='text/javascript' src='js/superfish-1.7.4.min.js'></script>
		<script type='text/javascript' src='js/main.js'></script>
		<script type='text/javascript' src='js/mediaelement-and-player.js'></script>
		<script type='text/javascript' src='js/player.js'></script>
	</body>
</html>